# Workspace guidance

Each workspace knows only itself and its descendants. Keep documentation,
guidance, registry entries, and commands rooted here; do not discover, inherit,
or reference workspace context outside this root. Descendant workspaces carry
their own self-contained instructions and remain independently usable.

Read README.md and `guidance/rules/index.md` before planning changes. Load the rules
matching the task and affected paths. Inspect the owning repository's Git status
and preserve unrelated work. A workspace directory is not necessarily one Git
repository; use workspace.json to locate the owner and its local instructions.

This workspace's `AI.md`, `guidance/rules/`, and `.agents/skills/` are its local
guidance sources. Keep them usable without depending on the generator checkout.
Before changing the CLI, registry, or templates, read
[`docs/workspace-model.md`](docs/workspace-model.md) and the relevant starter
guidance.

Each independent project carries its own required guidance, tests and dependencies.
Use project-local commands and installed versions. Workspace check commands delegate
to the registry; inspect their configured arguments before executing them.

For task procedures, use the skill linked from `guidance/rules/index.md`. Read a skill
only when that task applies. Client discovery support varies; explicit paths work
without installing a client adapter.

Before handoff, report the result, actual checks, remaining limitations and whether
changes are uncommitted. Follow the authorisation boundaries in the change rules.
